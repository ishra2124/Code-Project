package PROJECT;
import javax.swing.*;
import java.util.ArrayList;

abstract class Account {
    private String name;
    private String password;
    private String nid;
    private String mobile;
    private double balance;
    private ArrayList<String> transactions;
    public Account(String name, String password, String nid, String mobile, double balance) {
        this.name = name;
        this.password =password;
        this.nid = nid;
        this.mobile = mobile;
        this.balance = balance;
        this.transactions = new ArrayList<>();
    }

    public String getName() {
        return name;
    }
    public String getPassword() {
        return password;
    }
    public String getNid() {
        return nid;
    }
    public String getMobile() {
        return mobile;
    }

    public double getBalance() {
        return balance;
    }
    public void deposit(double amount) {
        balance += amount;
        transactions.add("Deposit:" + amount);
    }
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            transactions.add("Withdraw:" + amount);
        } else {
            JOptionPane.showMessageDialog(null, "Insufficient balance!");
        }
    }
    public ArrayList<String> getTransactions() {
        return transactions;
    }
}
