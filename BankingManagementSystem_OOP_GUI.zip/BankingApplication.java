package PROJECT;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class BankingApplication {
    static ArrayList<Account> accounts = new ArrayList<>();
    public static void main (String[]args){
        JFrame frame = new JFrame("Home Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 450);
        frame.setResizable(false);
        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 450, 450);
        panel.setLayout(null);
        JLabel banklabel = new JLabel("*//^\\\\*Banking Application");
        banklabel.setBounds(100, 25, 300, 100);
        banklabel.setFont(new Font("Arial", Font.BOLD, 22));
        banklabel.setForeground(new Color(0xF37507));
        panel.add(banklabel);
        JLabel label1 = new JLabel("Account ID: ");
        label1.setBounds(40, 100, 150, 40);
        label1.setForeground(new Color(0xFFFFFF));
        panel.add(label1);
        JTextField textField1 = new JTextField();
        textField1.setBounds(140, 100, 150, 40);
        panel.add(textField1);
        JLabel label2 = new JLabel("Password: ");
        label2.setBounds(40, 160, 150, 40);
        label2.setForeground(new Color(0xFFFFFF));
        panel.add(label2);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(140, 160, 150, 40);
        panel.add(passwordField);
        JButton button1 = new JButton("Log In");
        button1.setBounds(155, 230, 100, 30);
        button1.setBackground(new Color(0xA5F3DB));
        panel.add(button1);
        JLabel label3 = new JLabel("Or");
        label3.setBounds(200, 270, 50, 20);
        label3.setForeground(new Color(0xFFFFFF));
        panel.add(label3);
        JButton button2 = new JButton("Register");
        button2.setBounds(155, 300, 100, 30);
        button2.setBackground(new Color(0xA5F3DB));
        panel.add(button2);
        ImageIcon image = new ImageIcon("C:\\Users\\USER\\IdeaProjects\\CodeForces\\src\\PROJECT\\bg.jpg");
        JLabel img1 = new JLabel(image);
        img1.setBounds(0, 0, 450, 450);
        panel.add(img1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredNID = textField1.getText();
                String enteredPassword = new String(passwordField.getPassword());
                boolean loggedIn = false;
                for (Account account : accounts) {
                    if (account.getNid().equals(enteredNID) && account.getPassword().equals(enteredPassword)) {
                        loggedIn = true;
                        if (account instanceof CheckingAccount) {
                            showCheckingAccountPage((CheckingAccount) account);
                        } else if (account instanceof SavingAccount) {
                            showSavingsAccountPage((SavingAccount) account);
                        }
                        break;
                    }
                }
                if (!loggedIn) {
                    JOptionPane.showMessageDialog(frame, "Invalid Account ID or Password!");

                }


            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showRegistrationPage();
                textField1.setText(null);
                passwordField.setText(null);

            }
        });
        frame.add(panel);
        frame.setVisible(true);
    }
    public static void showRegistrationPage () {
        JFrame registerFrame = new JFrame("Register");
        registerFrame.setSize(450, 450);
        registerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        registerFrame.setResizable(false);
        JPanel registerPanel = new JPanel();
        registerPanel.setBackground(new Color(0x5FB6C6));
        registerPanel.setLayout(null);
        JLabel nameLabel = new JLabel("Name: ");
        nameLabel.setBounds(20, 10, 100, 30);
        JTextField nameField = new JTextField();
        nameField.setBounds(110, 10, 150, 30);
        JLabel passwordLabel = new JLabel("Password: ");
        passwordLabel.setBounds(20, 60, 100, 30);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(110, 60, 150, 30);
        JLabel accountTypeLabel = new JLabel("Account Type: ");
        accountTypeLabel.setBounds(20, 110, 100, 30);
        String[] accountTypes = {"Select", "Checking", "Savings"};
        JComboBox<String> accountTypeBox = new JComboBox<>(accountTypes);
        accountTypeBox.setBounds(110, 110, 150, 30);
        JLabel nidLabel = new JLabel("NID: ");
        nidLabel.setBounds(20, 160, 100, 30);
        JTextField nidField = new JTextField();
        nidField.setBounds(110, 160, 150, 30);
        JLabel mobileLabel = new JLabel("Mobile: ");
        mobileLabel.setBounds(20, 210, 100, 30);
        JTextField mobileField = new JTextField();
        mobileField.setBounds(110, 210, 150, 30);
        JLabel amountLabel = new JLabel("Amount: ");
        amountLabel.setBounds(20, 260, 100, 30);
        JTextField amountField = new JTextField();
        amountField.setBounds(110, 260, 150, 30);
        JButton registerButton = new JButton("Click here to Complete Registration");
        registerButton.setBounds(100, 310, 250, 30);
        JLabel l = new JLabel("Your NID is your Account ID");
        l.setFont(new Font("Arial", Font.BOLD, 14));
        l.setBounds(110, 340,250,30);
        registerButton.setBackground(new Color(0x08EC96));
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String password = new String(passwordField.getPassword());
                String accountType = (String) accountTypeBox.getSelectedItem();
                String nid = nidField.getText();
                String mobile = mobileField.getText();
                double balance = Double.parseDouble(amountField.getText());
                if (accountType.equals("Checking")) {
                    accounts.add(new CheckingAccount(name, password, nid, mobile, balance));
                } else if (accountType.equals("Savings")) {
                    accounts.add(new SavingAccount(name, password, nid, mobile, balance));
                }
                JOptionPane.showMessageDialog(registerFrame, "Successfully Registered!");
                registerFrame.dispose();
            }


        });
        registerPanel.add(nameLabel);
        registerPanel.add(nameField);
        registerPanel.add(passwordLabel);
        registerPanel.add(passwordField);
        registerPanel.add(accountTypeLabel);
        registerPanel.add(accountTypeBox);
        registerPanel.add(nidLabel);
        registerPanel.add(nidField);
        registerPanel.add(mobileLabel);
        registerPanel.add(mobileField);
        registerPanel.add(amountLabel);
        registerPanel.add(amountField);
        registerPanel.add(registerButton);
        registerPanel.add(l);
        registerFrame.add(registerPanel);
        registerFrame.setVisible(true);
    }
    public static void showCheckingAccountPage (CheckingAccount account) {

        JFrame checkingFrame = new JFrame("Checking Account");
        checkingFrame.setSize(450, 450);
        checkingFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        checkingFrame.setResizable(false);
        JPanel checkingPanel = new JPanel();
        checkingPanel.setLayout(null);
        checkingPanel.setBackground(new Color(0xFFACAC));
        JLabel balanceLabel = new JLabel("Balance: ");
        balanceLabel.setBounds(50, 50, 120, 30);
        checkingPanel.add(balanceLabel);
        JTextField balanceField = new JTextField(String.valueOf(account.getBalance()));
        balanceField.setBounds(180, 50, 100, 30);
        balanceField.setEditable(false);
        checkingPanel.add(balanceField);
        JLabel depositLabel = new JLabel("Deposit Amount: ");
        depositLabel.setBounds(50, 100, 120, 30);
        checkingPanel.add(depositLabel);
        JTextField depositField = new JTextField();
        depositField.setBounds(180, 100, 100, 30);
        checkingPanel.add(depositField);
        JButton depositButton = new JButton("Deposit");
        depositButton.setBounds(300, 100, 100, 30);
        depositButton.setBackground(new Color(0x57FA02));
        checkingPanel.add(depositButton);
        JLabel withdrawLabel = new JLabel("Withdraw Amount: ");
        withdrawLabel.setBounds(50, 150, 120, 30);
        checkingPanel.add(withdrawLabel);
        JTextField withdrawField = new JTextField();
        withdrawField.setBounds(180, 150, 100, 30);
        checkingPanel.add(withdrawField);
        JButton withdrawButton = new JButton("Withdraw");
        withdrawButton.setBounds(300, 150, 100, 30);
        withdrawButton.setBackground(new Color(0x57FA02));
        checkingPanel.add(withdrawButton);
        JButton transactionHistoryButton = new JButton("Transaction History");
        transactionHistoryButton.setBounds(50, 200, 250, 30);
        transactionHistoryButton.setBackground(new Color(0x50FD23));
        checkingPanel.add(transactionHistoryButton);
        JButton accountInfoButton = new JButton("Account Information");
        accountInfoButton.setBounds(50, 250, 250, 30);
        accountInfoButton.setBackground(new Color(0x63F30D));
        checkingPanel.add(accountInfoButton);
        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double amount = Double.parseDouble(depositField.getText());
                    account.deposit(amount);
                    JOptionPane.showMessageDialog(checkingFrame, "Deposit successful!");
                    balanceField.setText(String.valueOf(account.getBalance()));
                }
                catch (Exception e1){
                    JOptionPane.showMessageDialog(checkingFrame, "Please enter a valid number.",
                            "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    System.out.println(e1);
                }
            }
        });
        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double amount = Double.parseDouble(withdrawField.getText());
                    account.withdraw(amount);
                    JOptionPane.showMessageDialog(checkingFrame, "Withdrawal successful!");
                    balanceField.setText(String.valueOf(account.getBalance()));
                }
                catch(Exception e1){
                    JOptionPane.showMessageDialog(checkingFrame, "Please enter a valid number.",
                            "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    System.out.println(e1);
                }
            }
        });

        transactionHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showTransactionHistory(account);
            }
        });
        accountInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAccountInformation(account);
            }
        });
        checkingFrame.add(checkingPanel);
        checkingFrame.setVisible(true);
    }
    public static void showSavingsAccountPage(SavingAccount account) {
        JFrame savingsFrame = new JFrame("Savings Account");
        savingsFrame.setSize(450, 500);
        savingsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        savingsFrame.setResizable(false);
        JPanel savingsPanel = new JPanel();
        savingsPanel.setBackground(new Color(0xEBBEEF));
        savingsPanel.setLayout(null);
        JLabel balanceLabel = new JLabel("Balance: " + account.getBalance());
        balanceLabel.setBounds(50, 50, 200, 30);
        savingsPanel.add(balanceLabel);
        JLabel interestLabel = new JLabel("Interest Rate: 5% annually");
        interestLabel.setBounds(50, 100, 200, 30);
        savingsPanel.add(interestLabel);
        JButton interestButton = new JButton("Calculate Interest");
        interestButton.setBounds(50, 150, 200, 30);
        interestButton.setBackground(new Color(0x9DEDA1));
        savingsPanel.add(interestButton);
        JLabel interestEarnedLabel = new JLabel();
        interestEarnedLabel.setBounds(50, 200, 300, 30);
        savingsPanel.add(interestEarnedLabel);
        interestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double interest = account.calculateInterest();
                interestEarnedLabel.setText("Interest Earned: " + interest);
            }
        });
        JLabel loanLabel = new JLabel("Apply for Loan:");
        loanLabel.setBounds(50, 250, 150, 30);
        savingsPanel.add(loanLabel);
        JTextField loanAmountField = new JTextField();
        loanAmountField.setBackground(new Color(0xF590FF));
        loanAmountField.setBounds(150, 250, 150, 30);
        savingsPanel.add(loanAmountField);
        JButton loanButton = new JButton("Request Loan");
        loanButton.setBounds(50, 300, 200, 30);
        loanButton.setBackground(new Color(0xACEC9C));
        savingsPanel.add(loanButton);
        JLabel loanStatusLabel = new JLabel();
        loanStatusLabel.setBounds(50, 350, 300, 30);
        savingsPanel.add(loanStatusLabel);
        loanButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double loanAmount = Double.parseDouble(loanAmountField.getText());
                    String status = account.requestLoan(loanAmount);
                    loanStatusLabel.setText(status);
                }
                catch (Exception e1){
                    JOptionPane.showMessageDialog(savingsFrame, "Please enter a valid number.",
                            "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    System.out.println(e1);
                }
            }
        });
        JButton accountInfoButton = new JButton("Account Information");
        accountInfoButton.setBounds(50, 400, 250, 30);
        accountInfoButton.setBackground(new Color(0xAFEAB0));
        savingsPanel.add(accountInfoButton);

        accountInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAccountInformation(account);
            }
        });
        savingsFrame.add(savingsPanel);
        savingsFrame.setVisible(true);
    }
    public static void showAccountInformation (Account account){
        JFrame infoFrame = new JFrame("Account Information");
        infoFrame.setSize(400, 300);
        infoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        String[] columnNames = {"Field", "Value"};
        String[][] data;
        if (account instanceof SavingAccount) {
            data = new String[][]{
                    {"Name", account.getName()},
                    {"Account Type", "Savings"},
                    {"NID", account.getNid()},
                    {"Mobile", account.getMobile()},
                    {"Balance", String.valueOf(account.getBalance())},
                    {"Interest Rate", "5%"}
            };
        } else {
            data = new String[][]{
                    {"Name", account.getName()}, {"Account Type", "Checking"},
                    {"NID", account.getNid()}, {"Mobile", account.getMobile()},
                    {"Balance", String.valueOf(account.getBalance())},
            };
        }

        JTable table = new JTable(data, columnNames);
        table.setEnabled(false);
        JScrollPane scrollPane = new JScrollPane(table);
        infoFrame.add(scrollPane);
        infoFrame.setVisible(true);
    }
    public static void showTransactionHistory (Account account){
        JFrame transactionFrame = new JFrame("Transaction History");
        transactionFrame.setSize(400, 300);
        transactionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        String[] columnNames = {"Transaction", "Amount"};
        String[][] data;
        ArrayList<String> transactions = account.getTransactions();
        data = new String[transactions.size()][2];
        for (int i = 0; i < transactions.size(); i++) {
            String[] parts = transactions.get(i).split(":");
            data[i][0] = parts[0];
            data[i][1] = parts[1];
        }
        JTable table = new JTable(data, columnNames);
        table.setEnabled(false);
        JScrollPane scrollPane = new JScrollPane(table);
        transactionFrame.add(scrollPane);
        transactionFrame.setVisible(true);
    }
}





