package PROJECT;

class SavingAccount extends Account {
    public SavingAccount(String name, String password, String nid, String mobile, double balance) {
        super(name, password, nid, mobile, balance);
    }
    public String getAccountType() {
        return "Savings Account";
    }
    public double calculateInterest() {
        return getBalance()*0.05;
    }
    public String requestLoan(double loanAmount) {
        if (loanAmount <= getBalance() * 2) {
            return "Loan Approved: " + loanAmount;
        } else {
            return "Loan Denied: Amount exceeds limit.";
        }
    }
}