package PROJECT;

class CheckingAccount extends Account {
    public CheckingAccount(String name, String password, String nid, String mobile, double balance) {
        super(name, password, nid, mobile, balance);
    }
}




